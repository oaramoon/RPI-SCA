import numpy as np
import argparse
from tflite_runtime.interpreter import Interpreter 
from trigger import Trigger
from oscilloscope import Oscilloscope
import pickle
import time

def main():
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--model', dest='model', action="store" , type=str)
    args = parser.parse_args()
    
    with open("logit_dataset.pkl", 'rb') as f:
        logits_dataset = pickle.load(f)

    
    # Instantiate the scope 
    scope = Oscilloscope()
    scope.single()

    #### Instantiate the trigger
    trigger = Trigger()
    
    model_path = args.model
    print("Model Path : ", model_path)
    interpreter = Interpreter(model_path)
    interpreter.allocate_tensors()
    input_details = interpreter.get_input_details()[0]
    output_details = interpreter.get_output_details()[0]
    
    data_transfer_time = 30
    
    for i,(logit_sample,label) in enumerate(logits_dataset):
    
        interpreter.set_tensor(input_details["index"], np.expand_dims(logit_sample, axis=0))
        collection_name = 'softmax-10-class-'+str(label)+'-'+str(i)
        time.sleep(0.25)
        trigger.set()
        interpreter.invoke()
        trigger.clear()
        time.sleep(0.25)
        scope.save_waveform(name=collection_name, wait_time=data_transfer_time)
        scope.single()
    

if __name__ == '__main__':
    main()
